<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "arm_medilab";

	// Create connection
	$conn = new mysqli ($servername, $username, $password, $database);

	
?>