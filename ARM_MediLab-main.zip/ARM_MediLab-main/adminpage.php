
<!DOCTYPE HTML>
<HTML>
	<head>
	<title>ARM Medi Lab</title>
	     <link rel=" shoutcut icon" type="image/png" href="img/favicon.png">
	
	<style>
	
	
	body { 
		margin-left : 25px;
		margin-right : 25px;
	}
	#logo {
		float : left ;
		margin-left : 15px;
	}
	
	#banner {
		margin-left : 12px;
	}
	
	#slogan{
		margin-top : -34px;
		color:  #8bcb34;
	}
	h1{
		color :  #095d83;
	
	}
	.footer {
		   left: 12px;
		   bottom: 12px;
		   width: 100%;
		   background-color: #8bcb34;
		   color: white;
		   text-align: center;
		   padding : 1px;
		}
	.gallery {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 40px;
 
}

figure {
  margin: 0;
}

img {
  width: 250px;
  height: 200px;
  cursor: pointer;
}

figcaption {
  text-align: center;
}
	</style>
	
	</head>
	
	<body>
	
		<div id = "logo">
			<a href = "home.html"><img src = "images/ARM Logo.png" width = "250px"></a>
		</div>
			<h1 text align="center" style="font-family:verdana ; font-size:55px " >ARM MEDI LAB</h1>
			<p text align = "center" style="font-family:verdana ; font-size:25px" id = "slogan">we care...</p>
			
			
		<br><br>
		<hr>
		
		<h1><center> Welcome Ronaldo </h1></center>
		
		<br><br><br>
		
		
	<div class="gallery">
  <figure>
    <a href="#.html">
      <img src="images/report.jpeg" alt="report">
    </a>
    <figcaption>Add new reports</figcaption>
  </figure>
  
  <figure>
    <a href="home.html">
      <img src="images/newtest.jpeg" alt="newtest">
    </a>
    <figcaption>Add new tests</figcaption>
  </figure> 
  
  <figure>
    <a href="page3.html">
      <img src="images/inquiry.jpeg" alt="inquiry"> 
    </a>
    <figcaption>Inquiry</figcaption>
  </figure>
  
  



<br><br><br>
<br><br><br>
		
		<div class="footer">
		  <p >Developed by : RAM | ram@gamil.com</p>
		</div>




</body>


</html>
