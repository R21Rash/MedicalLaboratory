<?php
$con = mysqli_connect('localhost', 'root', '', 'tb_user');
if (!$con) {
    die("Connection error: " . mysqli_connect_error());
}
?>







