function loadData(data){
	if (data == "btn1"){
		document.getElementById("img").data="pdf/sample rpt.pdf";
		document.getElementById("para").innerHTML="Report No XXXX XXXX XXXX XXXX";
	}
}