<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Forgot Password</h2>
    <form action="send-verification.php" method="POST"  >
      <label for="email">Email Address:</label>
      <input type="email" id="email" name="email" required>
      
	  <a href="verifycode.php" > <button type ="button" value="login" id="login">Send Verification Code</button></a>
	
    </form>
  </div>
</body>
</html>